package macro.recorder.pkgfinal.project;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.stage.Stage;

public class MacroRecorder extends Application implements MouseListener{

    Macro macro = new Macro();
    private Integer play = 0;
    
    public static void main(String[] args) {
     
        Application.launch(args);
        
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        
    }
    @Override
    public void mousePressed(MouseEvent e) {
        
    }
    @Override
    public void mouseReleased(MouseEvent e) {
       
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        
    }
    @Override
    public void mouseExited(MouseEvent e) {
        
    }

    @Override
    public void start(Stage stage) throws Exception {
        
        //Define GUI Elements
        BorderPane pane = new BorderPane();
        GridPane grid = new GridPane();
        Button btnRecord = new Button("Record");
        Button btnPlay = new Button("Play");
        TextFlow introFlow = new TextFlow();
        Text intro = new Text();
        TextFlow recordDesc = new TextFlow();
        Text recordText = new Text();
        TextFlow playDesc = new TextFlow();
        Text playText = new Text();
        TextFlow errorDesc = new TextFlow();
        Text errorText = new Text();
        
        //Define Element Properties
        pane.setPadding(new Insets(20,20,20,20));
        btnRecord.setPrefSize(100, 40);
        btnPlay.setPrefSize(100, 40);
        grid.setHgap(25);
        grid.setVgap(25);
        grid.setPadding(new Insets(0, 10, 0, 10));
        intro.setText("Welcome to My Macro Program!\n Functionality currently includes recording your mouse movements and clicks with the Record button, and then replaying them with the Play button!\n\n\n\n\n\n");
        introFlow.getChildren().add(intro);
        recordText.setText("Click Record to record your cursor and clicks for 10 seconds.");
        recordDesc.getChildren().add(recordText);
        playText.setText("Once you have a Macro recorded, replay it by clicking play!");
        playDesc.getChildren().add(playText);
        errorText.setText("No File found, record one first!");
        errorDesc.getChildren().add(errorText);
        errorDesc.setVisible(false);
        
        
        //Place Elements Inside Each Other
        grid.add(btnRecord, 0, 0);
        grid.add(btnPlay, 0, 1);
        grid.add(recordDesc, 1, 0);
        grid.add(playDesc, 1, 1);
        grid.add(errorDesc, 0, 2, 2, 2);
        pane.setCenter(grid);
        pane.setTop(introFlow);
        
        //Create Scene and show it
        Scene scene = new Scene(pane, 550, 400);
        stage.setTitle("Macro Recorder!");
        stage.setScene(scene);
        stage.show();
        
        //Listeners
        
        btnRecord.setOnMouseClicked((e)->{
            stage.setIconified(true);
            macro.record();
            stage.setIconified(false);
        });
        btnPlay.setOnMouseClicked((e)->{
            stage.setIconified(true);
            play = macro.play();
            stage.setIconified(false);
            if(play == -1){
                errorDesc.setVisible(true);
            }
        });
        
    }

  
    
    
    
}

