package macro.recorder.pkgfinal.project;


public class TestPlay {
    
    public static void main(String[] args) {

        //Record a file with TestRecord before you try to play one. There is one in there by default but it may not work.
        Macro macro = new Macro();
       
        macro.play();
    }
}
