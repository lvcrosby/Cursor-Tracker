package macro.recorder.pkgfinal.project;


public class TestRecord {
    
    
    public static void main(String[] args) {
     
        //Record file before trying to play one
        Macro macro = new Macro();
      
        
        macro.record();
    }
    
}
