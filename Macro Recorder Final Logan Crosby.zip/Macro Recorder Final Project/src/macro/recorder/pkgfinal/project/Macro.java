package macro.recorder.pkgfinal.project;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.MouseInfo;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.JFrame;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Macro implements MouseListener{

    private String name = "macro.macro";
    private String saveLocation = System.getProperty("user.dir");
    private int mousex = 0;
    private int mousey = 0;
    private int maxTime = 1000;
    private int mbPressed = 0;
    private int mbReleased = 0;
    
    public Macro(){
        
    }

    public Macro(String saveLocation) {
        this.saveLocation = saveLocation;
    }

    public Macro(String name, String fileLocation) {
        this.name = name;
        this.saveLocation = fileLocation;
    }
    
    public String getName(){
        return name;
    }

    public int getMaxTime() {
        return maxTime;
    }
    
    public String getSaveLocation() {
        return saveLocation;
    }

    public void setSaveLocation(String saveLocation) {
        this.saveLocation = saveLocation;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setMaxTime(int maxTime) {
        this.maxTime = maxTime;
    }
    
    
    
    public Integer checkFile(){
     
        Integer duration = 0;
        return duration;
    }

    
    @Override
    public void mouseClicked(MouseEvent e) {
        
    }

    @Override
    public void mousePressed(MouseEvent e) {
        mbPressed = e.getButton();
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        mbReleased = e.getButton();
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        
    }

    @Override
    public void mouseExited(MouseEvent e) {
        
    }
    
    
    public Integer record(){
        
        
        try{
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            
            int time;
            JFrame frame = new JFrame("MouseWindow");
            frame.setAlwaysOnTop(false);
            frame.setUndecorated(true);
            frame.setSize(screenSize.width * 3, screenSize.height * 3);
            frame.addMouseListener(this);
            frame.setBackground(new Color(1,1,1,1));
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
            
            try{
                //Creating XML file
                DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
                DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();
                Document document = documentBuilder.newDocument();
                
                //Root Element
                Element xml = document.createElement("xml");
                document.appendChild(xml);
                //Macro Element
                Element macro = document.createElement("macro");
                xml.appendChild(macro);
                //Defining Elements
                Element macroname = document.createElement("name");
                Element mouse = document.createElement("mouse");
                Element key = document.createElement("key");
                //Appending Children
                macroname.appendChild(document.createTextNode(name));
                macro.appendChild(macroname);
                macro.appendChild(mouse);
                macro.appendChild(key);
                
                
                
                for(time = 0; time < maxTime; time++){
                    //gets and records mouse movements
                    mousex = MouseInfo.getPointerInfo().getLocation().x;
                    mousey = MouseInfo.getPointerInfo().getLocation().y;
                    
                    mouse.appendChild(document.createTextNode("#" + time + "//" + mousex + "," + mousey));
                    System.out.println("#" + time + "//" + mousex + "," + mousey);
                    
                    if(mbPressed != 0){
                        key.appendChild(document.createTextNode("#" + time + "//" + mbPressed));
                        
                        if(mbReleased == mbPressed){
                            key.appendChild(document.createTextNode("#" + time + "//" + mbReleased));
                            mbPressed = 0;
                            mbReleased = 0;
                        }
                    }
                    
                    Thread.sleep(9);
                }
                
                TransformerFactory transformerFactory = TransformerFactory.newInstance();
                Transformer transformer = transformerFactory.newTransformer();
                DOMSource domSource = new DOMSource(document);
                StreamResult streamResult = new StreamResult(new File(saveLocation + "//" + name));
                
                transformer.transform(domSource, streamResult);
                
                System.out.println("Save successful");
                
                
                frame.dispose();
                
                
            }catch (Exception e){
                e.printStackTrace();
                System.out.println(e.toString());
                if("FileNotFoundException".equals(e.toString())){
                    return 2;
                }
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return 1;
    }//end record()
    
    
    public Integer play(){

        
        try{
            //Moves cursor to (0, 0) for debugging
            Robot robot = new Robot();
            robot.mouseMove(mousex, mousey);
            
            //Accessing file
            File macroFile = new File(saveLocation + "//" + name);
            if(macroFile.canRead() == true){
                DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                Document doc = dBuilder.parse(macroFile);

                doc.getDocumentElement().normalize();
                //Moving through XML
                System.out.println("Root element: " + doc.getDocumentElement().getNodeName());

                NodeList nList = doc.getElementsByTagName("mouse");
                Node nNode = nList.item(0);

                NodeList nList2 = doc.getElementsByTagName("key");
                Node nNode2 = nList2.item(0);

                System.out.println("Element: " + nNode.getNodeName());

                if(nNode.getNodeType() == Node.ELEMENT_NODE){
                    Element mouseElement = (Element)nNode;
                    String mouseString = mouseElement.getTextContent();
                    String[] mouses = mouseString.split("#");
                    

                    Element keyElement = (Element)nNode2;
                    String keyString = keyElement.getTextContent();
                    System.out.println(keyString);
                    ArrayList<String> keys = new ArrayList<>(Arrays.asList(keyString.split("#")));

                    Boolean token = false;
                    int i = 1;
                    String[] oldKey = new String[2];
                    //For loop for moving mouse and pressing buttons
                    for(int time = 1; time < mouses.length; time++){
                        String[] temp = mouses[time].split("//");
                        String[] temp2 = temp[1].split(",");
                        robot.mouseMove(Integer.parseInt(temp2[0]), Integer.parseInt(temp2[1]));

                        String currString;
                        String[] keyPress;
                        if(keys.size()>2){
                            
                            currString = keys.get(i);
                            keyPress = currString.split("//");
                        }else{
                        
                            currString = "-1//0";
                            keyPress = currString.split("//");
                        }
                        
                        

                        if(Integer.parseInt(keyPress[0]) == time){
                            System.out.println(i);
                            if(token == false){
                                System.out.println(keyPress[1]);
                                Integer mask = InputEvent.getMaskForButton(Integer.parseInt(keyPress[1]));
                                robot.mousePress(mask);
                                token = true;                       
                                oldKey[0] = keyPress[0];
                                oldKey[1] = keyPress[1];
                            }
                            if(i != keys.size() - 1){
                                i++;
                            }
                        }else if(token == true && Integer.parseInt(keyPress[0]) != Integer.parseInt(oldKey[0])){
                            //Logic for when to release button, only when there is no button press in the current time slot
                            System.out.println("Released");
                            Integer mask2 = InputEvent.getMaskForButton(Integer.parseInt(oldKey[1]));
                            robot.mouseRelease(mask2);
                            token = false;
                            if(i != keys.size()-1){
                                i++;
                            }

                        }

                        Thread.sleep(10);

                    }

                }
            }else{
               return -1;
            }
            
            
            
        }catch(Exception e){
            e.printStackTrace();
        }
        return 1;
    }//end play() 
    
}//end class
